import { Component, OnInit } from '@angular/core';

import { Todo } from '../models/todo.model';
import { TodoService } from '../todo.service';


import { Http , Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-add-todo',
  templateUrl: './add-todo.component.html',
  styleUrls: ['./add-todo.component.css']  
})
export class AddTodoComponent implements OnInit {

  public todoList: Todo[];
  public todoInput: string;
  constructor(private _todo: TodoService) { }

  ngOnInit() {

    this.getTodos();
  }

  getTodos() {
    this._todo.getTodos()
      .subscribe(itodo => this.todoList = itodo);
  }

  addTodo() {
    if(this.todoInput === '' || this.todoInput === undefined ) {
      alert("Please Enter the Todo task");
    } else  {
    
    let todo = new Todo();
    todo.name = this.todoInput;
    todo.status = false;
    this._todo.addTodos(todo).subscribe(
      ()=>{},
      ()=>{},
      () => this.getTodos() );
    
    
    this.todoInput = '' 
    
  }

  }

  doneClicked(name: string , taskId: string) {
    let todo = new Todo();
    todo.id = taskId;
    todo.name = name;
    todo.status = true;
    this._todo.updateTodos(todo).subscribe(
      ()=>{},
      ()=>{},
      () => this.getTodos()
    );
  }

  deleteTask(taskId: string) {
    let todo = new Todo();
    todo.id = taskId;    
    this._todo.updateTodos(todo).subscribe();
  }


}
