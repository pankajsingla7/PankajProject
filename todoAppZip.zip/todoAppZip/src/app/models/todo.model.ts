export class Todo {
    id: string;
    name: string;
    status: boolean;
}