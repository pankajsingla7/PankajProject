import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { RouterModule, Routes } from '@angular/router';
import { HttpModule  } from '@angular/http';

import { AppComponent } from './app.component';
import { AddTodoComponent } from './add-todo/add-todo.component';
import { FormsModule } from '@angular/forms';
import { TodoService } from './todo.service';

const appRoutes: Routes = [
  { path: 'addTodo', component: AddTodoComponent }
];



@NgModule({
  declarations: [
    AppComponent,
    AddTodoComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    HttpModule,
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: true } // <-- debugging purposes only
    )
  ],
  exports: [
    RouterModule
  ],
  providers: [TodoService],
  bootstrap: [AppComponent]
})
export class AppModule { }
