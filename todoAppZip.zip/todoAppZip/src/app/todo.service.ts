import { Injectable } from '@angular/core';

import { Todo } from './models/todo.model'

import { Http , Response , RequestOptions , Headers } from '@angular/http'; 
import { Observable } from 'rxjs/Observable'; 

import 'rxjs/add/operator/map'; 
import 'rxjs/add/operator/do'; 
import 'rxjs/add/operator/catch'; 

@Injectable()
export class TodoService {

  private _getTodoUrl = 'http://localhost:8080/api/todo'; 

  private _addTodoUrl = 'http://localhost:8080/api/todo'; 

  private _updateTodoUrl = 'http://localhost:8080/api/todo/';

  constructor(private _http: Http) { }

  getOptions() : RequestOptions  {
    let headers = new Headers({ 'Access-Control-Allow-Origin': '*' });
    let options = new RequestOptions({ headers : headers});
    return options;
  }


  getTodos(): Observable<Todo[]> { 
    return this._http.get(this._getTodoUrl, this.getOptions() )
    .map(response =>
       <Todo[]> response.json());
    // .do(data => console.log(JSON.stringify(data))) 
    // .catch(this.handleError); 
 }

 addTodos(todoInput: Todo) :Observable<any> {
   return  this._http.post(this._addTodoUrl, todoInput);
 }

 updateTodos(todoInput: Todo) :any {
  return  this._http.put(this._updateTodoUrl + todoInput.id , todoInput, this.getOptions());
 }

 deleteTodos(todoInput: Todo) :any {
  return  this._http.delete(this._updateTodoUrl + todoInput.id , this.getOptions());
 }


 
 private handleError(error: Response) { 
    console.error(error); 
    return Observable.throw(error.json().error()); 
 } 

}
